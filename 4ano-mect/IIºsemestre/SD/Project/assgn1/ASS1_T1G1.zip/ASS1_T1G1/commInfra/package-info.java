/**
 *   Common infrastructure.
 */

package commInfra;
