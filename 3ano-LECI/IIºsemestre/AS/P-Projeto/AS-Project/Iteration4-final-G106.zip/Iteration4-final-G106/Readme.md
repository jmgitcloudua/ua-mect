# campingSpot
Plataforma de reserva tendas/espaço de parques de campismo

## Group members «106»

| NMec | Name | email |
|--:|---|---|
| 97147 | Jodionísio Muachifi | jodionsiomuachifi@ua.pt |
| 102578 | João Mourão |  jmourao@ua.pt |
| 102487 | João Rodrigues | joaopprodrigues08@ua.pt |


## Link da Plataforma 
 - https://www.campingspot.cf/code/login.html
 - https://www.campingspot.cf/code/index.html

## Link para acesso ao repositório
 - https://github.com/AS-CampingSpot/campingSpot

## Intruções para utilizar a plataforma
 - Se utilizar o link com login, primeiro deve-se fazer criar a conta
 - Para ver plataforma, pode-se utilizar diretamente o link com index page