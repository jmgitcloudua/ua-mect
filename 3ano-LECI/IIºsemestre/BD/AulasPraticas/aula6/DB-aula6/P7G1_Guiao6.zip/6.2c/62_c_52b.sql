SELECT AVG(unidades) AS und FROM item GROUP BY numEnc;
