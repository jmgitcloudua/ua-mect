# Programming Elements - Lab Work nº 2
## Group members - G1

|  NMec | Name                | email                   |
| ----: | ------------------- | ----------------------- |
| 97147 | Jodionísio Muachifi | jodionsiomuachifi@ua.pt |
| 118200 |  Miguel Simões    | miguelbsimoes@ua.pt   |
| 118485 | Gustavo Reggio    | gustavo.reggio@ua.pt    |


## Structure of navigation files:
**partI** - where you have all the files <br>
**partI/script** - where you can find small script used to plot graphs in python and matlab <br>
**partI/images** - where you can find all images about the execution results and graphs <br>
**partI/python_nn** - where you can find the version of neural network coded using python<br>


## Instructions to compile/run PartI:
```
 git clone https://github.com/jmgitcloudua/ep_labwork2.git
 cd partI
 make
 ```
**h** - number of hidden layer <br>
**n** - number of iterations <br>
**lr** - learning rate <br>
**s** - seed
### Verification
To check tthe output of the neural network that we have calculated by hand, we can run
```
 ./verify_test_design
```
### Test nº 1 - (h = 12, n = 1.000, lr = 0.1)
```
 ./train_nn train -h 12 -n 1000 -lr 0.1 xor.train
```
```
 ./train_nn train -h 12 -n 1000 -lr 0.1 -s 123 xor.train
```
### Test nº 2 - (h = 12, n = 10.000, lr = 0.01)
```
 ./train_nn train -h 12 -n 10000 -lr 0.01 xor.train
```
```
 ./train_nn train -h 12 -n 10000 -lr 0.01 -s 123 xor.train
```
### Test nº 3 - (h = 12, n = 10.000, lr = 0.01)
```
 ./train_nn train -h 12 -n 10000 -lr 0.001 xor.train
```
```
 ./train_nn train -h 12 -n 10000 -lr 0.001 -s 123 xor.train
```
### Test nº 4 - (h = 12, n = 100.000, lr = 0.001)
```
 ./train_nn train -h 12 -n 100000 -lr 0.001 xor.train
```
```
 ./train_nn train -h 12 -n 100000 -lr 0.001 -s 123 xor.train
```
### Test nº 5 - (h = 12, n = 10.000, lr = 0.5)
```
 ./train_nn train -h 12 -n 10000 -lr 0.5 xor.train
```
```
 ./train_nn train -h 12 -n 10000 -lr 0.5 -s 123 xor.train
```
### Test nº 6 - (h = 12, n = 100.000, lr = 0.5)
```
 ./train_nn train -h 12 -n 100000 -lr 0.5 xor.train
```
```
 ./train_nn train -h 12 -n 100000 -lr 0.5 -s 123 xor.train
```
### Test nº 7 - (h = 12, n = 1.000.000, lr = 0.5)
```
 ./train_nn train -h 12 -n 1000000 -lr 0.5 xor.train
```
```
 ./train_nn train -h 12 -n 1000000 -lr 0.5 -s 123 xor.train
```

### Run unit test
Again, make sure you are in the folder partI and follow the instruction below to run it
```
 ./unit_tests
```

### Clean files (.o) and others

```
 make clean
```

## Extras
We have developed the same code for nn using Python.

### Instructions to run nn Python version:
```
 cd python_nn
```
- install pip
- setup virtual environment
- install the necessary library (available in requirements.txt)
```
sudo apt install python3-pip
```
```
sudo apt install python3-venv
```
```
python3 -m venv venv
```
```
source venv/bin/activate
```
```
pip install -r requirements.txt
```
- Run the same tests already mentioned using C
- Run unit tests
- When you run the plot files, the image output is saved in current folder.  
### Test - (h = 12, n = 10.000, lr = 0.1)
```
python3 train_nn.py -h 12 -n 10000 -lr 0.1 xor.train
```
```
python3 train_nn.py -h 12 -n 10000 -lr 0.1 -s 123 xor.train
```
**Obs.**: you can try several tests.

### Run unit test
```
python3 unit_tests.py
```
### Plot graph
```
python3 plot_nn.py
```
### Plot graph (for C language)
Make sure you are in the folder **partI/scripts** and follow the instruction below to run it. Also be aware to move or copy the file **training_data.csv** generated in partI folder to scripts in order to plot graph.
```
 python3 plot_nn.py
```
**Memo**: in the folder mentioned above, there are others files that you can test to plot graphs or can use matlab you plot these. The image output is saved in current folder. <br>


If you want to deactivate de virtual environment, do simply as follow:
```
deactivate
```

## Link References
 - https://www.w3schools.com/c/c_structs.php
 - https://en.wikipedia.org/wiki/Pointer_(computer_programming)
 - https://www.youtube.com/watch?v=Ilg3gGewQ5U
 - https://elearning.ua.pt/mod/url/view.php?id=1336755 
- https://en.wikipedia.org/wiki/Backpropagation
- https://en.wikipedia.org/wiki/Neural_network
- https://en.wikipedia.org/wiki/GNU_Debugger
- https://en.wikipedia.org/wiki/Valgrind
