//verify_test_design.c

#include <stdio.h>
#include <math.h>

// Sigmoid function
double sigmoid(double x) {
    return 1.0 / (1.0 + exp(-x));
}

// Forward pass function
double forward_pass(double input1, double input2, double w_ih[2][2], double w_ho[2], double b_h[2], double b_o) {
    double hidden1, hidden2, output;

    // Calculate the inputs and outputs of the hidden units
    hidden1 = sigmoid(input1 * w_ih[0][0] + input2 * w_ih[1][0] + b_h[0]);
    hidden2 = sigmoid(input1 * w_ih[0][1] + input2 * w_ih[1][1] + b_h[1]);

    // Calculate the input and output of the output unit
    output = sigmoid(hidden1 * w_ho[0] + hidden2 * w_ho[1] + b_o);

    return output;
}

int main() {
    // Define the weights and biases
    double w_ih[2][2] = {{0.5, -0.5}, {0.5, 0.5}};
    double w_ho[2] = {0.5, -0.5};
    double b_h[2] = {0.5, -0.5};
    double b_o = 0.5;

    // Define the input vector
    double input1 = 1.0;
    double input2 = 1.0;

    // Perform a forward pass and print the output
    double output = forward_pass(input1, input2, w_ih, w_ho, b_h, b_o);
    printf("Output = %f\n", output);

    return 0;
}
