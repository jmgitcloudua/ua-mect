import numpy as np
import matplotlib.pyplot as plt

# Sigmoid function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Derivative of the sigmoid function
def sigmoid_derivative(x):
    return sigmoid(x) * (1 - sigmoid(x))

# Generate x values
x_values = np.linspace(-5, 5, 1000)

# Calculate y values for the sigmoid function and its derivative
y_sigmoid = sigmoid(x_values)
y_derivative = sigmoid_derivative(x_values)

# Plotting
plt.figure(figsize=(8, 6))

plt.plot(x_values, y_sigmoid, label=r'$\frac{1}{1 + e^{-x}}$ (Sigmoid)', linewidth=2)
plt.plot(x_values, y_derivative, label=r"Sigmoid's Derivative ($f'(x) = f(x)(1 - f(x))$)", linestyle='dashed', linewidth=2)

plt.title('Sigmoid Function and Its Derivative')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.tight_layout()
#plt.show()
# Save the plot to an image file
plt.savefig('sigmoid_derivative2.png')
