import numpy as np
import matplotlib.pyplot as plt

# Define the sigmoid function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Generate x values
x = np.linspace(-5, 5, 1000)

# Calculate corresponding y values using the sigmoid function
y = sigmoid(x)

# Plot the sigmoid function
plt.figure()
plt.plot(x, y, linewidth=2)
plt.title('Sigmoid Activation Function')
plt.xlabel('Input (x)')
plt.ylabel('Output (f(x))')
plt.grid(True)
#plt.show()
# Save the plot to an image file
plt.savefig('activation_function.png')
