% Read CSV file
data = readtable('training_data.csv');

% Plot MSE vs Iteration
figure;
subplot(1, 2, 1);
plot(data.Iteration, data.MSE, 'o-');
xlabel('Iteration');
ylabel('MSE');
title('MSE vs Iteration');

% Plot MSE vs Time
subplot(1, 2, 2);
plot(data.Time, data.MSE, 'o-');
xlabel('Time (seconds)');
ylabel('MSE');
title('MSE vs Time');
