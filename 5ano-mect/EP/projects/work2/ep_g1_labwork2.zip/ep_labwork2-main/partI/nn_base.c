// nn_base.c
/*  Implementation file for a simple module implementing a fully connected neural network
  with a single layer of hidden units. Note that the module is incomplete.
  This time, we set the definition of the bias of the units and implement a non-linear activation function.
*/
// Armando J. Pinho (ap@ua.pt)
// IEETA / LASI / DETI / University of Aveiro
// 2023
/*Students EP/G1/2023-2024:
    - Jodionísio Muachifi
    - Miguel Simões
    - Gustavo Reggio
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nn_base.h"

// Creates a fully connected neural network with one hidden layer of units
nn_t *create_nn(unsigned I, unsigned H, unsigned O, unsigned seed)
{
    nn_t *nn;

    if ((nn = (nn_t *)malloc(sizeof(nn_t))) == NULL)
    {
        fprintf(stderr, "Error: memory allocation failure\n");
        exit(1);
    }

    nn->I = I;
    nn->H = H;
    nn->O = O;

    if ((nn->inp = (double *)calloc(I, sizeof(double))) == NULL ||
        (nn->u_h = (unit_t *)calloc(H, sizeof(unit_t))) == NULL ||
        (nn->u_o = (unit_t *)calloc(O, sizeof(unit_t))) == NULL ||
        (nn->w_ih = (double **)calloc(I, sizeof(double *))) == NULL ||
        (nn->w_ho = (double **)calloc(H, sizeof(double *))) == NULL ||
        (nn->b_h = (double *)calloc(H, sizeof(double))) == NULL ||
        (nn->b_o = (double *)calloc(O, sizeof(double))) == NULL)
    {
        fprintf(stderr, "Error: memory allocation failure\n");
        exit(1);
    }

    srand(seed); // Seed for random initialization

    for (unsigned i = 0; i < I; i++)
    {
        if ((nn->w_ih[i] = (double *)calloc(H, sizeof(double))) == NULL)
        {
            fprintf(stderr, "Error: memory allocation failure\n");
            exit(1);
        }

        // Initialize weights randomly only if it's the first time
        if (seed == 0)
        {
            for (unsigned h = 0; h < H; h++)
            {
                nn->w_ih[i][h] = (double)rand() / RAND_MAX;
            }
        }
    }

    for (unsigned h = 0; h < H; h++)
    {
        if ((nn->w_ho[h] = (double *)calloc(O, sizeof(double))) == NULL)
        {
            fprintf(stderr, "Error: memory allocation failure\n");
            exit(1);
        }

        // Initialize weights randomly only if it's the first time
        if (seed == 0)
        {
            for (unsigned o = 0; o < O; o++)
            {
                nn->w_ho[h][o] = (double)rand() / RAND_MAX;
            }
        }
    }

    return nn;
}

void load_header(FILE *fp, unsigned *I, unsigned *H, unsigned *O)
{
    if (fscanf(fp, "%u %u %u", I, H, O) != 3)
    {
        fprintf(stderr, "Error: reading file header\n");
        exit(1);
    }
}

void load_weights(FILE *fp, nn_t *nn)
{
    unsigned li, ui, lo, uo;
    double w;

    while (fscanf(fp, "%u:%u %u:%u %lf", &li, &ui, &lo, &uo, &w) == 5)
    {
        if (lo != li + 1)
        {
            fprintf(stderr, "Error: connections only allowed between consecutive layers\n");
            exit(1);
        }

        switch (li)
        {
        case 1:
            nn->w_ih[ui - 1][uo - 1] = w;
            break;
        case 2:
            nn->w_ho[ui - 1][uo - 1] = w;
            break;
        }
    }
}

void save_nn(FILE *fp, nn_t *nn)
{
    if (fprintf(fp, "%u %u %u\n", nn->I, nn->H, nn->O) < 0)
    {
        fprintf(stderr, "Error: writing file header\n");
        exit(1);
    }

    for (unsigned i = 0; i < nn->I; i++)
        for (unsigned h = 0; h < nn->H; h++)
            fprintf(fp, "1:%d 2:%d %f\n", i + 1, h + 1, nn->w_ih[i][h]);

    for (unsigned h = 0; h < nn->H; h++)
        for (unsigned o = 0; o < nn->O; o++)
            fprintf(fp, "2:%d 3:%d %f\n", h + 1, o + 1, nn->w_ho[h][o]);
}

unsigned load_input_vector(FILE *fp, nn_t *nn)
{
    for (unsigned i = 0; i < nn->I; i++)
        if (fscanf(fp, "%lf", &nn->inp[i]) != 1)
            return 0;

    return nn->I;
}

static double unit_activation(double inp)
{
    return 1.0 / (1.0 + exp(-inp));
}
double sigmoid_derivative(double x)
{
    return x * (1.0 - x);
}
void go_forward(nn_t *nn)
{
    // From input to hidden
    for (unsigned h = 0; h < nn->H; h++)
    {
        nn->u_h[h].inp = nn->b_h[h]; // Initialize with the bias term
        for (unsigned i = 0; i < nn->I; i++)
            nn->u_h[h].inp += nn->inp[i] * nn->w_ih[i][h];

        nn->u_h[h].out = unit_activation(nn->u_h[h].inp);
    }

    // From hidden to output
    for (unsigned o = 0; o < nn->O; o++)
    {
        nn->u_o[o].inp = nn->b_o[o]; // Initialize with the bias term
        for (unsigned h = 0; h < nn->H; h++)
            nn->u_o[o].inp += nn->u_h[h].out * nn->w_ho[h][o];

        nn->u_o[o].out = unit_activation(nn->u_o[o].inp);
    }
}

void print_input(nn_t *nn)
{
    for (unsigned i = 0; i < nn->I; i++)
        printf("%.3f ", nn->inp[i]);

    printf("\n");
}

void print_output(nn_t *nn)
{
    for (unsigned o = 0; o < nn->O; o++)
        printf("%.3f ", nn->u_o[o].out);

    printf("\n");
}

void print_input_and_output(nn_t *nn)
{
    printf("[");
    for (unsigned i = 0; i < nn->I; i++)
        printf("%.3f ", nn->inp[i]);
    printf("] -> ");

    for (unsigned o = 0; o < nn->O; o++)
        printf("%.3f ", nn->u_o[o].out);

    printf("\n");
}

// /** Backpropagation **/
void backpropagation(nn_t *nn, double *target, double learning_rate)
{
    double error, delta;

    // Calculate error and delta for output layer
    for (unsigned o = 0; o < nn->O; o++)
    {
        error = target[o] - nn->u_o[o].out;
        delta = error * sigmoid_derivative(nn->u_o[o].out);

        // Update weights and bias for output layer
        for (unsigned h = 0; h < nn->H; h++)
        {
            nn->w_ho[h][o] += learning_rate * delta * nn->u_h[h].out;
        }
        // nn->u_o[o].bias += learning_rate * delta;
        nn->b_o[o] += learning_rate * delta;

        // Calculate error and delta for hidden layer
        for (unsigned h = 0; h < nn->H; h++)
        {
            error = delta * nn->w_ho[h][o];
            delta = error * sigmoid_derivative(nn->u_h[h].out);

            // Update weights and bias for hidden layer
            for (unsigned i = 0; i < nn->I; i++)
            {
                nn->w_ih[i][h] += learning_rate * delta * nn->inp[i];
            }
            // nn->u_h[h].bias += learning_rate * delta;
            nn->b_h[h] += learning_rate * delta;
        }
    }
}
// Calculate the mean squared error (MSE)
double mean_squared_error(nn_t *nn, double *target)
{
    double error = 0.0;
    for (unsigned o = 0; o < nn->O; o++)
    {
        double diff = target[o] - nn->u_o[o].out;
        error += diff * diff;
    }
    return error / nn->O;
}

// Load input vector from an array
void load_input_vector_from_array(nn_t *nn, double *input_array)
{
    for (unsigned i = 0; i < nn->I; i++)
    {
        nn->inp[i] = input_array[i];
    }
}

// free the memory allocated for the neural network
void free_nn(nn_t *nn)
{
    free(nn->inp);
    free(nn->u_h);
    free(nn->u_o);
    for (unsigned i = 0; i < nn->I; i++)
        free(nn->w_ih[i]);
    for (unsigned h = 0; h < nn->H; h++)
        free(nn->w_ho[h]);
    free(nn->w_ih);
    free(nn->w_ho);
    free(nn->b_h);
    free(nn->b_o);
    free(nn);
}