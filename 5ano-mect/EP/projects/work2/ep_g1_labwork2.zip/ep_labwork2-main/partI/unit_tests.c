// units_test.c

#include <stdio.h>
#include <assert.h> // Include the assert header
#include "nn_base.h"

int tests_passed = 0;
int tests_failed = 0;

void test_create_nn();
void test_load_save_nn();
void test_train_xor();
void test_bias();

int main()
{
    test_create_nn();
    test_load_save_nn();
    test_train_xor();
    test_bias();

    printf("\033[32m\nTests Passed:\033[0m %d\n", tests_passed);
    printf("\033[31mTests Failed: \033[0m %d\n", tests_failed);

    if (tests_failed > 0)
    {
        printf("Some tests failed.\n");
    }
    else
    {
        printf("\033[32m All tests passed.\033[0m\n");
    }

    return 0;
}
void test_create_nn()
{
    printf("Running test_create_nn...\n");

    nn_t *nn = create_nn(2, 3, 1, 123);

    // Check if nn is not NULL
    assert(nn != NULL);

    // Check if the sizes are correctly set
    assert(nn->I == 2);
    assert(nn->H == 3);
    assert(nn->O == 1);

    free_nn(nn);

    tests_passed++;
    printf("\033[32m test_create_nn passed! \033[0m\n");
}

void test_load_save_nn()
{
    printf("Running test_load_save_nn ...\n");

    nn_t *nn = create_nn(2, 3, 1, 123);

    // Save the original weights for later comparison
    double **original_w_ih = nn->w_ih;
    double **original_w_ho = nn->w_ho;

    FILE *save_file = fopen("test_nn_save.txt", "w");
    save_nn(save_file, nn);
    fclose(save_file);

    FILE *load_file = fopen("test_nn_load.txt", "r");
    nn_t *loaded_nn = create_nn(2, 3, 1, 123); // Use the same seed
    load_header(load_file, &loaded_nn->I, &loaded_nn->H, &loaded_nn->O);
    load_weights(load_file, loaded_nn);
    fclose(load_file);

    // Check if sizes are correctly loaded
    assert(loaded_nn->I == 2);
    assert(loaded_nn->H == 3);
    assert(loaded_nn->O == 1);

    // Check if weights are correctly loaded
    for (unsigned i = 0; i < nn->I; i++)
    {
        for (unsigned h = 0; h < nn->H; h++)
        {
            assert(nn->w_ih[i][h] == original_w_ih[i][h]);
        }
    }

    for (unsigned h = 0; h < nn->H; h++)
    {
        for (unsigned o = 0; o < nn->O; o++)
        {
            assert(nn->w_ho[h][o] == original_w_ho[h][o]);
        }
    }

    free_nn(nn);
    free_nn(loaded_nn);

    tests_passed++;
    printf("\033[32m test_load_save_nn passed! \033[0m\n");
}
void test_train_xor()
{
    printf("Running test_train_xor ...\n");

    nn_t *nn = create_nn(2, 3, 1, 0);

    // Define XOR training data
    double input_data[4][2] = {{0, 0}, {0, 1}, {1, 0}, {1, 1}};
    double target_data[4] = {0, 1, 1, 0};

    // Train the XOR network
    for (unsigned iteration = 0; iteration < 1000000; iteration++)
    {
        double total_error = 0.0;

        for (unsigned i = 0; i < 4; i++)
        {
            load_input_vector_from_array(nn, input_data[i]);

            // Forward pass
            go_forward(nn);

            // Backpropagation
            backpropagation(nn, &target_data[i], 0.05);

            // Calculate total error for monitoring
            total_error += mean_squared_error(nn, &target_data[i]);
        }

        if (iteration % 1000 == 0)
        {
            printf("Iteration %u: MSE = %f\n", iteration, total_error / 4.0);
        }
    }

    // Test the trained XOR network
    printf("Testing the trained XOR network:\n");
    for (int i = 0; i < 4; i++)
    {
        load_input_vector_from_array(nn, input_data[i]);
        go_forward(nn);

        printf("[%f %f] -> %f (Expected: %f)\n", nn->inp[0], nn->inp[1], nn->u_o[0].out, target_data[i]);
        assert((nn->u_o[0].out > 0.5) == (target_data[i] > 0.5)); // Uncomment this line for binary comparison
    }

    free_nn(nn);

    tests_passed++;
    printf("\033[32m test_train_xor passed! \033[0m\n");
}

void test_bias()
{
    printf("Running test_bias ...\n");

    nn_t *nn = create_nn(2, 3, 1, 123);

    // Test if the biases are correctly initialized
    assert(nn->b_h[0] == 0.0); // First hidden layer bias
    assert(nn->b_o[0] == 0.0); // Output layer bias

    // Set biases to non-zero values
    nn->b_h[0] = 0.1;
    nn->b_o[0] = -0.2;

    // Check if biases are correctly set
    assert(nn->b_h[0] == 0.1);
    assert(nn->b_o[0] == -0.2);

    free_nn(nn);

    tests_passed++;
    printf("\033[32m test_bias passed! \033[0m\n");
}
