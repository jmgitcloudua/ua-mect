# train_nn.py - Train a neural network to learn the XOR function
import numpy as np
import time
from nn_base import NeuralNetwork

DEFAULT_HIDDEN_UNITS = 10
DEFAULT_ITERATIONS = 1000
DEFAULT_LEARNING_RATE = 0.01


def validate_hidden_units(input):
    if input < 0:
        print("\033[31mError: Hidden units cannot be negative. Using default value.\033[0m")
        return DEFAULT_HIDDEN_UNITS
    return int(input)


def validate_iterations(input):
    if input < 0 or input < 1000 or input > 100000000000:
        print("\033[31mError: Iterations must be a positive integer between 1000 and 100000000000. Using default value.\033[0m")
        return DEFAULT_ITERATIONS
    return int(input)


def validate_learning_rate(input):
    if input <= 0 or input > 1:
        print("\033[31mError: Learning rate must be a positive number between 0 and 1. Using default value.\033[0m")
        return DEFAULT_LEARNING_RATE
    return input


def print_usage():
    print("\033[33mUsage: train_nn.py -h hidden_units -n n_iterations -lr learning_rate -s seed training_file\033[0m")


def load_xor_training_data(file_path):
    with open(file_path, 'r') as file:
        num_vectors = int(file.readline())
        num_inputs, num_outputs = map(int, file.readline().split())

        input_data = np.zeros((num_vectors, num_inputs))
        target_data = np.zeros(num_vectors)

        for i in range(num_vectors):
            line_values = list(map(float, file.readline().split()))
            
            # Extract the first 'num_inputs' values as inputs
            input_data[i, :num_inputs] = line_values[:num_inputs]
            
            # The last value is the target
            target_data[i] = line_values[-1]

    return num_vectors, num_inputs, num_outputs, input_data, target_data


def main():
    # Default values
    hidden_units = DEFAULT_HIDDEN_UNITS
    n_iterations = DEFAULT_ITERATIONS
    learning_rate = DEFAULT_LEARNING_RATE
    seed = 0  # Seed for random weights
    training_file = None

    # Parse command-line arguments
    import sys
    argv = sys.argv[1:]

    i = 0
    while i < len(argv):
        if argv[i] == "-h" and i + 1 < len(argv):
            hidden_units = validate_hidden_units(int(argv[i + 1]))
        elif argv[i] == "-n" and i + 1 < len(argv):
            n_iterations = validate_iterations(int(argv[i + 1]))
        elif argv[i] == "-lr" and i + 1 < len(argv):
            learning_rate = validate_learning_rate(float(argv[i + 1]))
        elif argv[i] == "-s" and i + 1 < len(argv):
            seed = int(argv[i + 1])
        elif i == len(argv) - 1:
            training_file = argv[i]
        i += 1

    # Check if any of the parameters failed validation
    if hidden_units == 0 or n_iterations == 0 or learning_rate == 0 or training_file is None:
        print_usage()
        exit(1)

    num_vectors, num_inputs, num_outputs, input_data, target_data = load_xor_training_data(training_file)

    # Create neural network with specified seed
    nn = NeuralNetwork(num_inputs, hidden_units, num_outputs, seed)

    # Before the training loop - create CSV file and write header
    with open("training_data.csv", "w") as csv_file:
        csv_file.write("Iteration,MSE,Time\n")

    # Training loop
    for iteration in range(n_iterations):
        total_error = 0.0

        # Load XOR training data from file
        for i in range(num_vectors):
            nn.load_input_vector_from_array(input_data[i])
            target = target_data[i]

            # Forward pass
            nn.go_forward()

            # Backpropagation
            nn.backpropagation(target, learning_rate)

            # Calculate total error for monitoring
            total_error += nn.mean_squared_error(target)

        # Print iteration information
        print("===================================================")
        start_time = time.time()  # Start timing here
        #print("\033[32mBackpropagation took", time.time(), "seconds\033[0m")

        # Test the trained neural network
        print("\033[34mTesting the trained XOR network:\033[0m")
        print("\033[33m[Iteration : MSE] ->", iteration, ":", total_error / 4.0, "\033[0m")
        correct_predictions = 0
        for i in range(num_vectors):
            nn.load_input_vector_from_array(input_data[i])
            nn.go_forward()
            print(f"[{nn.inp[0]} {nn.inp[1]}] -> {nn.u_o[0]}")
        
        # Check accuracy
        if np.round(nn.u_o[0]) == target_data[i]:
            correct_predictions += 1
        
        end_time = time.time()  # Stop timing here
        total_time_taken = end_time - start_time
        print("\033[32mBackpropagation took", total_time_taken, "seconds\033[0m")


        # Calculate energy consumption (just an example, actual energy consumption is hardware-specific)
        # Assuming a constant power consumption rate (in watts)
        power_consumption_rate = 100.0  # Replace with actual power consumption rate
        energy_consumption = power_consumption_rate * total_time_taken

        # Calculate accuracy
        accuracy = correct_predictions / num_vectors
        #print(f"Accuracy: {accuracy * 100:.2f}%")
        print(f"Energy Consumption: {energy_consumption:.2f} joules")

        # Check accuracy
        raw_output = nn.u_o[0]
        #print(f"Raw Output: {raw_output}")
        if raw_output > 0.5:
            prediction = 1
        else:
            prediction = 0

        if prediction == target_data[i]:
            correct_predictions += 1

        # Calculate accuracy using the correct_predictions variable
        accuracy = (correct_predictions / num_vectors) * 100
        print(f"Accuracy: {accuracy:.2f}%")

        # Append iteration, MSE, and time taken to CSV file
        with open("training_data.csv", "a") as csv_file:
            csv_file.write(f"{iteration},{total_error / 4.0},{total_time_taken}\n")

    # Save the state of the neural network
    with open("train.net", "w") as save_file:
        nn.save_nn(save_file)

    # Free allocated memory
    nn.free_nn()


if __name__ == "__main__":
    main()
