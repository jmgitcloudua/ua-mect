# nn_base.py

import numpy as np

class NeuralNetwork:
    def __init__(self, I, H, O, seed=0):
        self.I = I
        self.H = H
        self.O = O
        np.random.seed(seed)

        self.inp = np.zeros(I)
        self.u_h = np.zeros(H)
        self.u_o = np.zeros(O)
        self.w_ih = np.random.rand(I, H)
        self.w_ho = np.random.rand(H, O)
        self.b_h = np.zeros(H)
        self.b_o = np.zeros(O)

    def load_header(self, fp):
        header = fp.readline().split()
        self.I, self.H, self.O = map(int, header)

    def load_weights(self, fp):
        for line in fp:
            li, ui, lo, uo, w = map(float, line.split())
            if lo != li + 1:
                raise ValueError("Connections only allowed between consecutive layers")

            if li == 1:
                self.w_ih[int(ui) - 1][int(uo) - 1] = w
            elif li == 2:
                self.w_ho[int(ui) - 1][int(uo) - 1] = w

    def save_nn(self, fp):
        fp.write(f"{self.I} {self.H} {self.O}\n")

        for i in range(self.I):
            for h in range(self.H):
                fp.write(f"1:{i + 1} 2:{h + 1} {self.w_ih[i][h]}\n")

        for h in range(self.H):
            for o in range(self.O):
                fp.write(f"2:{h + 1} 3:{o + 1} {self.w_ho[h][o]}\n")

    def load_input_vector(self, fp):
        line = fp.readline()
        self.inp = np.array(list(map(float, line.split())))
        return len(self.inp)

    @staticmethod
    def unit_activation(inp):
        return 1.0 / (1.0 + np.exp(-inp))

    @staticmethod
    def sigmoid_derivative(x):
        return x * (1.0 - x)

    def go_forward(self):
        # From input to hidden
        self.u_h = self.b_h + np.dot(self.inp, self.w_ih)
        self.u_h = self.unit_activation(self.u_h)

        # From hidden to output
        self.u_o = self.b_o + np.dot(self.u_h, self.w_ho)
        self.u_o = self.unit_activation(self.u_o)

    def print_input(self):
        print(" ".join(map(str, self.inp)))

    def print_output(self):
        print(" ".join(map(str, self.u_o)))

    def print_input_and_output(self):
        print(f"[{', '.join(map(str, self.inp))}] -> {', '.join(map(str, self.u_o))}")

    def backpropagation(self, target, learning_rate):
        error = target - self.u_o
        delta = error * self.sigmoid_derivative(self.u_o)

        # Update weights and bias for output layer
        self.w_ho += learning_rate * np.outer(self.u_h, delta)
        self.b_o += learning_rate * delta

        # Calculate error and delta for hidden layer
        error = np.dot(delta, self.w_ho.T)
        delta = error * self.sigmoid_derivative(self.u_h)

        # Update weights and bias for hidden layer
        self.w_ih += learning_rate * np.outer(self.inp, delta)
        self.b_h += learning_rate * delta

    def mean_squared_error(self, target):
        error = np.mean((target - self.u_o) ** 2)
        return error

    def load_input_vector_from_array(self, input_array):
        self.inp = np.array(input_array)

    def free_nn(self):
        # No need for explicit freeing in Python, handled by the garbage collector
        pass

