import pandas as pd
import matplotlib.pyplot as plt

def plot_training_data(file_path):
    # Read data from CSV file
    df = pd.read_csv(file_path)

    # Plot MSE over iterations
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.plot(df['Iteration'], df['MSE'], marker='o')
    plt.title('Mean Squared Error (MSE) over Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('MSE')

    # Plot Time over iterations
    plt.subplot(1, 2, 2)
    plt.plot(df['Iteration'], df['Time'], marker='o')
    plt.title('Time Taken over Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('Time (seconds)')

    plt.tight_layout()
    #plt.show()

    # Save the plot to an image file
    plt.savefig('training_data_plot.png')

if __name__ == "__main__":
    plot_training_data("training_data.csv")
