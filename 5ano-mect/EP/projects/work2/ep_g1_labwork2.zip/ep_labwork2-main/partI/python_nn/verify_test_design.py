import numpy as np

# Sigmoid function
def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

# Forward pass function
def forward_pass(input1, input2, w_ih, w_ho, b_h, b_o):
    hidden1 = sigmoid(input1 * w_ih[0, 0] + input2 * w_ih[1, 0] + b_h[0])
    hidden2 = sigmoid(input1 * w_ih[0, 1] + input2 * w_ih[1, 1] + b_h[1])
    output = sigmoid(hidden1 * w_ho[0] + hidden2 * w_ho[1] + b_o)
    return output

def main():
    # Define the weights and biases using NumPy arrays
    w_ih = np.array([[0.5, -0.5], [0.5, 0.5]])
    w_ho = np.array([0.5, -0.5])
    b_h = np.array([0.5, -0.5])
    b_o = 0.5

    # Define the input vector
    input1 = 1.0
    input2 = 1.0

    # Perform a forward pass and print the output
    output = forward_pass(input1, input2, w_ih, w_ho, b_h, b_o)
    rounded_output = round(output, 6)
    print(f"Output = {rounded_output}")

if __name__ == "__main__":
    main()
