# unit_tests.py
import unittest
import numpy as np
from nn_base import NeuralNetwork
from train_nn import load_xor_training_data

class TestNeuralNetwork(unittest.TestCase):
    def setUp(self):
        # Create a neural network with a fixed seed for reproducibility
        self.nn = NeuralNetwork(I=2, H=4, O=1, seed=42)

    def test_forward_pass(self):
        # Test the forward pass for a specific input
        self.nn.load_input_vector_from_array([0, 1])
        self.nn.go_forward()
        self.assertEqual(len(self.nn.u_o), 1)

    def test_backpropagation(self):
        # Test the backpropagation for a specific input and target
        self.nn.load_input_vector_from_array([1, 1])
        target = 0
        self.nn.go_forward()
        self.nn.backpropagation(target, learning_rate=0.1)
        self.assertEqual(len(self.nn.u_o), 1)

    def test_mean_squared_error(self):
        # Test mean squared error calculation
        target = np.array([0.5])
        mse = self.nn.mean_squared_error(target)
        self.assertTrue(isinstance(mse, float))

class TestTrainNN(unittest.TestCase):
    def test_load_xor_training_data(self):
        # Test loading XOR training data
        num_vectors, num_inputs, num_outputs, input_data, target_data = load_xor_training_data("xor.train")
        self.assertEqual(num_vectors, 4)
        self.assertEqual(num_inputs, 2)
        self.assertEqual(num_outputs, 1)
        self.assertEqual(input_data.shape, (4, 2))
        self.assertEqual(target_data.shape, (4,))

if __name__ == '__main__':
    # Run the tests
    test_suite = unittest.TestLoader().loadTestsFromTestCase(TestNeuralNetwork)
    test_suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestTrainNN))
    result = unittest.TextTestRunner(verbosity=2).run(test_suite)

    # Display the results with appropriate colors and messages
    tests_passed = result.wasSuccessful()
    tests_failed = len(result.failures) + len(result.errors)

    if tests_passed:
        print("\033[32m\nAll tests passed!\033[0m")
    else:
        print("\033[31m\nSome tests failed.\033[0m")

    print("\033[32mTests Passed:\033[0m", result.testsRun - tests_failed)
    print("\033[31mTests Failed:\033[0m", tests_failed)
