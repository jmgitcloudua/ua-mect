#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <linux/time.h>
#include <unistd.h> // for sleep()
#include "nn_base.h"

/*Students EP/G1/2023-2024:
    - Jodionísio Muachifi
    - Miguel Simões
    - Gustavo Reggio
*/

#define DEFAULT_HIDDEN_UNITS 10
#define DEFAULT_ITERATIONS 1000
#define DEFAULT_LEARNING_RATE 0.01

void validate_hidden_units(unsigned *hidden_units);
void validate_iterations(unsigned *iterations);
void validate_learning_rate(double *learning_rate);
void print_usage();
void load_xor_training_data(char *file_path, unsigned *num_vectors, unsigned *num_inputs, unsigned *num_outputs, double ***input_data, double **target_data);

int main(int argc, char *argv[])
{
    unsigned hidden_units = DEFAULT_HIDDEN_UNITS;
    unsigned n_iterations = DEFAULT_ITERATIONS;
    double learning_rate = DEFAULT_LEARNING_RATE;
    unsigned seed = 0;
    char *training_file = NULL;

    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-h") == 0 && i + 1 < argc)
        {
            hidden_units = atoi(argv[i + 1]);
            validate_hidden_units(&hidden_units);
        }
        else if (strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            n_iterations = atoi(argv[i + 1]);
            validate_iterations(&n_iterations);
        }
        else if (strcmp(argv[i], "-lr") == 0 && i + 1 < argc)
        {
            learning_rate = atof(argv[i + 1]);
            validate_learning_rate(&learning_rate);
        }
        else if (strcmp(argv[i], "-s") == 0 && i + 1 < argc)
        {
            seed = atoi(argv[i + 1]);
        }
        else if (i == argc - 1)
        {
            training_file = argv[i];
        }
        i++;
    }

    if (hidden_units == 0 || n_iterations == 0 || learning_rate == 0 || training_file == NULL)
    {
        print_usage();
        exit(1);
    }

    unsigned num_vectors, num_inputs, num_outputs;
    double **input_data;
    double *target_data;

    load_xor_training_data(training_file, &num_vectors, &num_inputs, &num_outputs, &input_data, &target_data);

    nn_t *nn = create_nn(num_inputs, hidden_units, num_outputs, seed);

    FILE *csv_file = fopen("training_data.csv", "w");
    if (!csv_file)
    {
        fprintf(stderr, "\033[31mError: Could not open file training_data.csv.\033[0m\n");
        exit(1);
    }
    fprintf(csv_file, "Iteration,MSE,Time\n");
    fclose(csv_file);

    clock_t start_time;

    for (unsigned iteration = 0; iteration < n_iterations; iteration++)
    {
        start_time = clock();

        double total_error = 0.0;
        unsigned correct_predictions = 0;
        unsigned prediction = 0;
        for (unsigned i = 0; i < num_vectors; i++)
        {
            load_input_vector_from_array(nn, input_data[i]);
            double target = target_data[i];

            go_forward(nn);
            backpropagation(nn, &target, learning_rate);

            total_error += mean_squared_error(nn, &target);

            // Check accuracy
            double raw_output = (*nn).u_o[0].out;
            prediction = (raw_output > 0.5) ? 1 : 0;

            if (prediction == target_data[i])
            {
                correct_predictions += 1;
            }
        }

        // print_iteration_info(iteration, total_error / num_vectors, start_time, correct_predictions, num_vectors);
        //*************************Displaying the output - Test the trained neural network*************************//
        printf("=====================================\n");
        printf("\033[34mTesting the trained XOR network:\n\033[0m");
        for (unsigned i = 0; i < num_vectors; i++)
        {
            load_input_vector_from_array(nn, input_data[i]);
            go_forward(nn);

            printf("[%f %f] -> %f\n", nn->inp[0], nn->inp[1], nn->u_o[0].out);
        }
        printf("\033[33m[Iteration : MSE] -> %u : %.6f\033[0m\n", iteration, total_error / num_vectors);
        // Some delay
        sleep(0.5);
        clock_t end_time = clock();
        double total_time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        printf("\033[32mBackpropagation took %.6f seconds\033[0m\n", total_time_taken);

        double accuracy = (double)correct_predictions / num_vectors * 100.0;
        printf("Accuracy: %.2f%%\n", accuracy);

        // Assuming a constant power consumption rate (in watts)
        double power_consumption_rate = 100.0; // Replace with actual power consumption rate
        double energy_consumption = power_consumption_rate * total_time_taken;
        printf("Energy Consumption: %.2f joules\n", energy_consumption);
        //*******end of the code output********//

        FILE *csv_file = fopen("training_data.csv", "a");
        if (!csv_file)
        {
            fprintf(stderr, "\033[31mError: Could not open file training_data.csv.\033[0m\n");
            exit(1);
        }
        fprintf(csv_file, "%u,%.6f,%.6f\n", iteration, total_error / num_vectors, ((double)(clock() - start_time)) / CLOCKS_PER_SEC);
        fclose(csv_file);
    }

    FILE *save_file = fopen("train.net", "w");
    if (!save_file)
    {
        fprintf(stderr, "\033[31mError: Could not open file train.net.\033[0m\n");
        exit(1);
    }
    save_nn(save_file, nn);
    fclose(save_file);

    free_nn(nn);

    for (unsigned i = 0; i < num_vectors; i++)
    {
        free(input_data[i]);
    }
    free(input_data);
    free(target_data);

    return 0;
}

void validate_hidden_units(unsigned *hidden_units)
{
    if (*hidden_units == 0)
    {
        fprintf(stderr, "\033[31mError: Hidden units cannot be zero. Using default value.\033[0m\n");
        *hidden_units = DEFAULT_HIDDEN_UNITS;
    }
}

void validate_iterations(unsigned *iterations)
{
    if (*iterations < 1000 || *iterations > 100000000000)
    {
        fprintf(stderr, "\033[31mError: Iterations must be between 1000 and 100000000000. Using default value.\033[0m\n");
        *iterations = DEFAULT_ITERATIONS;
    }
}

void validate_learning_rate(double *learning_rate)
{
    if (*learning_rate <= 0 || *learning_rate > 1)
    {
        fprintf(stderr, "\033[31mError: Learning rate must be between 0 and 1. Using default value.\033[0m\n");
        *learning_rate = DEFAULT_LEARNING_RATE;
    }
}

void print_usage()
{
    printf("\033[33mUsage: train_nn -h hidden_units -n n_iterations -lr learning_rate -s seed training_file\033[0m\n");
}

void load_xor_training_data(char *file_path, unsigned *num_vectors, unsigned *num_inputs, unsigned *num_outputs, double ***input_data, double **target_data)
{
    FILE *file = fopen(file_path, "r");
    if (!file)
    {
        fprintf(stderr, "\033[31mError: Could not open file %s.\033[0m\n", file_path);
        exit(1);
    }

    if (fscanf(file, "%u", num_vectors) != 1 || fscanf(file, "%u %u", num_inputs, num_outputs) != 2)
    {
        fprintf(stderr, "\033[31mError: Invalid file format.\033[0m\n");
        fclose(file);
        exit(1);
    }

    *input_data = (double **)malloc(*num_vectors * sizeof(double *));
    *target_data = (double *)malloc(*num_vectors * sizeof(double));

    for (unsigned i = 0; i < *num_vectors; i++)
    {
        (*input_data)[i] = (double *)malloc(*num_inputs * sizeof(double));

        for (unsigned j = 0; j < *num_inputs; j++)
        {
            if (fscanf(file, "%lf", &(*input_data)[i][j]) != 1)
            {
                fprintf(stderr, "\033[31mError: Invalid file format.\033[0m\n");
                fclose(file);
                exit(1);
            }
        }

        if (fscanf(file, "%lf", &(*target_data)[i]) != 1)
        {
            fprintf(stderr, "\033[31mError: Invalid file format.\033[0m\n");
            fclose(file);
            exit(1);
        }
    }

    fclose(file);
}